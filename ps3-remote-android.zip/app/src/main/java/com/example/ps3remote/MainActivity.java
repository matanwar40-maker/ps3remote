package com.example.ps3remote;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        web.setBackgroundColor(0xFF0A0B0D);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void deliver(final String js) {
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private static String httpGet(String u, int timeout, int max) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u.replace(" ", "%20")).openConnection();
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0 && out.size() < max) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    private static String localPrefix() throws Exception {
        String best = null;
        for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!ni.isUp() || ni.isLoopback()) continue;
            for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                    String h = a.getHostAddress();
                    String p = h.substring(0, h.lastIndexOf('.') + 1);
                    if (ni.getName().startsWith("wlan")) return p;
                    if (best == null) best = p;
                }
            }
        }
        return best;
    }

    private static String probe(String host) {
        try {
            Socket s = new Socket();
            s.connect(new InetSocketAddress(host, 80), 600);
            s.close();
        } catch (Exception e) {
            return null;
        }
        try {
            String low = httpGet("http://" + host + "/cpursx.ps3", 2000, 4096).toLowerCase();
            if (low.contains("webman") || low.contains("rsx")) return host;
        } catch (Exception e) { }
        return null;
    }

    private class Bridge {
        @JavascriptInterface
        public void setIp(String ip) {
            getSharedPreferences("ps3", MODE_PRIVATE).edit().putString("ip", ip).apply();
        }

        @JavascriptInterface
        public void send(final String url, final String label) {
            try {
                Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (vib != null) vib.vibrate(10);
            } catch (Exception e) { }
            new Thread(() -> {
                boolean ok = false;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url.replace(" ", "%20")).openConnection();
                    c.setConnectTimeout(3000);
                    c.setReadTimeout(3000);
                    c.getResponseCode();
                    ok = true;
                    c.disconnect();
                } catch (Exception e) { }
                final boolean res = ok;
                deliver("onNative(" + res + "," + JSONObject.quote(label) + ")");
            }).start();
        }

        @JavascriptInterface
        public void scan() {
            new Thread(() -> {
                JSONArray found = new JSONArray();
                try {
                    String prefix = localPrefix();
                    if (prefix != null) {
                        ExecutorService pool = Executors.newFixedThreadPool(48);
                        List<Future<String>> jobs = new ArrayList<>();
                        for (int i = 1; i < 255; i++) {
                            final String host = prefix + i;
                            jobs.add(pool.submit(() -> probe(host)));
                        }
                        for (Future<String> f : jobs) {
                            try {
                                String r = f.get();
                                if (r != null) found.put(r);
                            } catch (Exception e) { }
                        }
                        pool.shutdown();
                    }
                } catch (Exception e) { }
                deliver("onScan(" + found.toString() + ")");
            }).start();
        }

        @JavascriptInterface
        public void games(final String ip) {
            new Thread(() -> {
                String js = "onGames(null)";
                try {
                    String html = httpGet("http://" + ip + "/index.ps3", 5000, 3000000);
                    Matcher m = Pattern.compile(
                        "href=[\"'](/mount[._]ps3/[^\"']+)[\"'][^>]*>(.*?)</a>",
                        Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(html);
                    JSONArray arr = new JSONArray();
                    Set<String> seen = new HashSet<>();
                    while (m.find()) {
                        String path = m.group(1);
                        int q = path.indexOf('?');
                        if (q > 0) path = path.substring(0, q);
                        if (!seen.add(path)) continue;
                        String name = m.group(2).replaceAll("<[^>]*>", "").replace("&amp;", "&").trim();
                        if (name.isEmpty()) {
                            name = URLDecoder.decode(path.substring(path.lastIndexOf('/') + 1), "UTF-8");
                        }
                        JSONObject o = new JSONObject();
                        o.put("n", name);
                        o.put("p", path);
                        arr.put(o);
                    }
                    js = "onGames(" + arr.toString() + ")";
                } catch (Exception e) { }
                deliver(js);
            }).start();
        }
    }
}
