package com.example.ps3remote;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        web.setBackgroundColor(0xFF0A0B0D);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    private class Bridge {
        @JavascriptInterface
        public void send(final String url, final String label) {
            try {
                Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (vib != null) vib.vibrate(15);
            } catch (Exception e) { }
            new Thread(() -> {
                boolean ok = false;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(3000);
                    c.setReadTimeout(3000);
                    c.getResponseCode();
                    ok = true;
                    c.disconnect();
                } catch (Exception e) { }
                final boolean res = ok;
                runOnUiThread(() -> web.evaluateJavascript(
                    "onNative(" + res + "," + JSONObject.quote(label) + ")", null));
            }).start();
        }
    }
}
