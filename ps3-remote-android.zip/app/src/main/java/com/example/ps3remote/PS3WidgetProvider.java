package com.example.ps3remote;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.RemoteViews;
import android.widget.Toast;
import java.net.HttpURLConnection;
import java.net.URL;

public class PS3WidgetProvider extends AppWidgetProvider {
    static final String ACTION = "com.example.ps3remote.PAD";

    static final int[] IDS = {
        R.id.b_l1, R.id.b_l2, R.id.b_r2, R.id.b_r1,
        R.id.b_up, R.id.b_down, R.id.b_left, R.id.b_right, R.id.b_enter,
        R.id.b_tri, R.id.b_sq, R.id.b_circ, R.id.b_cross,
        R.id.b_sel, R.id.b_ps, R.id.b_start
    };
    static final String[] CMDS = {
        "l1", "l2", "r2", "r1",
        "up", "down", "left", "right", "cross",
        "triangle", "square", "circle", "cross",
        "select", "ps", "start"
    };

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] widgetIds) {
        for (int w : widgetIds) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_remote);
            for (int i = 0; i < IDS.length; i++) {
                Intent in = new Intent(c, PS3WidgetProvider.class);
                in.setAction(ACTION);
                in.setData(Uri.parse("ps3://pad/" + i));
                in.putExtra("cmd", CMDS[i]);
                PendingIntent pi = PendingIntent.getBroadcast(c, i, in,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                v.setOnClickPendingIntent(IDS[i], pi);
            }
            m.updateAppWidget(w, v);
        }
    }

    @Override
    public void onReceive(final Context c, Intent in) {
        if (!ACTION.equals(in.getAction())) {
            super.onReceive(c, in);
            return;
        }
        final String cmd = in.getStringExtra("cmd");
        final String ip = c.getSharedPreferences("ps3", Context.MODE_PRIVATE).getString("ip", "");
        final PendingResult pr = goAsync();
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            String msg = null;
            if (ip.isEmpty()) {
                msg = "Open the app and save the PS3 IP first";
            } else {
                try {
                    HttpURLConnection con = (HttpURLConnection) new URL("http://" + ip + "/pad.ps3?" + cmd).openConnection();
                    con.setConnectTimeout(3000);
                    con.setReadTimeout(3000);
                    con.getResponseCode();
                    con.disconnect();
                } catch (Exception e) {
                    msg = "PS3 not reachable";
                }
            }
            if (msg != null) {
                final String shown = msg;
                h.post(() -> Toast.makeText(c, shown, Toast.LENGTH_SHORT).show());
            }
            pr.finish();
        }).start();
    }
}
