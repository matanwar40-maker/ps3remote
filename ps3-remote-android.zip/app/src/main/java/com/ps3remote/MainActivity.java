package com.ps3remote;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    WebView wv;
    final ExecutorService ex = Executors.newFixedThreadPool(6);
    final ExecutorService padEx = Executors.newSingleThreadExecutor();
    final AtomicInteger pending = new AtomicInteger();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        wv = new WebView(this);
        wv.setBackgroundColor(Color.BLACK);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        wv.addJavascriptInterface(new Bridge(), "Native");
        wv.loadUrl("file:///android_asset/index.html");
    }

    void js(final String type, final String payload) {
        runOnUiThread(() -> wv.evaluateJavascript(
            "window.onNative(" + JSONObject.quote(type) + "," + JSONObject.quote(payload) + ")", null));
    }

    class Bridge {
        @JavascriptInterface
        public String getIp() { return Net.ip(MainActivity.this); }

        @JavascriptInterface
        public void setIp(String ip) { Net.prefs(MainActivity.this).edit().putString("ip", ip.trim()).apply(); }

        @JavascriptInterface
        public void pad(final String cmd) {
            if (!cmd.matches("[A-Za-z0-9_]+")) return;
            if (pending.get() > 3 && !cmd.equals("release")) return;
            pending.incrementAndGet();
            padEx.execute(() -> {
                String r = Net.get(Net.ip(MainActivity.this), "/pad.ps3?" + cmd, 2500, 20000);
                pending.decrementAndGet();
                js("send", r != null ? "ok" : "fail");
            });
        }

        @JavascriptInterface
        public void scan() {
            ex.execute(() -> {
                String f = Net.scan(MainActivity.this);
                js("scan", f == null ? "" : f);
            });
        }

        @JavascriptInterface
        public void games() {
            ex.execute(() -> {
                String body = Net.get(Net.ip(MainActivity.this), "/index.ps3", 8000, 3000000);
                JSONArray arr = new JSONArray();
                if (body != null) {
                    Matcher m = Pattern.compile("href=\"(/mount[^\"]*)\"[^>]*>([^<]+)<").matcher(body);
                    while (m.find() && arr.length() < 500) {
                        try {
                            JSONObject o = new JSONObject();
                            o.put("n", m.group(2).replace("&amp;", "&").trim());
                            o.put("p", m.group(1).replace("&amp;", "&"));
                            arr.put(o);
                        } catch (Exception ignored) { }
                    }
                }
                js("games", arr.toString());
            });
        }

        @JavascriptInterface
        public void play(final String path) {
            ex.execute(() -> {
                String ip = Net.ip(MainActivity.this);
                Net.get(ip, path, 8000, 20000);
                try { Thread.sleep(3000); } catch (Exception ignored) { }
                Net.get(ip, "/play.ps3", 5000, 20000);
                js("play", "ok");
            });
        }
    }
}
