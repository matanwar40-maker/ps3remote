package com.ps3remote;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.RemoteViews;
import android.widget.Toast;

public class PS3Widget extends AppWidgetProvider {
    static final int[] IDS = {R.id.b_l2,R.id.b_l1,R.id.b_r1,R.id.b_r2,R.id.b_up,R.id.b_tri,R.id.b_left,R.id.b_ok,R.id.b_right,R.id.b_sq,R.id.b_ci,R.id.b_down,R.id.b_cr,R.id.b_select,R.id.b_ps,R.id.b_start};
    static final String[] CMDS = {"l2","l1","r1","r2","up","triangle","left","cross","right","square","circle","down","cross","select","psbtn","start"};

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] widgetIds) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget);
        for (int i = 0; i < IDS.length; i++) {
            Intent in = new Intent(ctx, PS3Widget.class).setAction("PAD").putExtra("cmd", CMDS[i]);
            rv.setOnClickPendingIntent(IDS[i], PendingIntent.getBroadcast(ctx, i, in,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        }
        mgr.updateAppWidget(widgetIds, rv);
    }

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        if (!"PAD".equals(intent.getAction())) return;
        final String cmd = intent.getStringExtra("cmd");
        final BroadcastReceiver.PendingResult pr = goAsync();
        new Thread(() -> {
            String ip = Net.ip(ctx);
            if (ip.isEmpty()) {
                toast(ctx, "Save the IP in the app first");
            } else if (Net.get(ip, "/pad.ps3?" + cmd, 2000, 20000) == null) {
                toast(ctx, "PS3 unreachable");
            }
            pr.finish();
        }).start();
    }

    static void toast(final Context c, final String m) {
        new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(c, m, Toast.LENGTH_SHORT).show());
    }
}
