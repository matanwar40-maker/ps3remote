package com.ps3remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Net {
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("ps3", Context.MODE_PRIVATE); }
    static String ip(Context c) { return prefs(c).getString("ip", ""); }

    static String get(String host, String path, int timeout, int maxBytes) {
        HttpURLConnection c = null;
        try {
            URL u = new URL("http://" + host + path.replace(" ", "%20"));
            c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(timeout);
            c.setReadTimeout(timeout);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && out.size() < maxBytes) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static String scan(Context ctx) {
        WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        int ipInt = wm.getConnectionInfo().getIpAddress();
        if (ipInt == 0) return null;
        final String prefix = (ipInt & 0xff) + "." + ((ipInt >> 8) & 0xff) + "." + ((ipInt >> 16) & 0xff) + ".";
        ExecutorService pool = Executors.newFixedThreadPool(64);
        List<Future<String>> fs = new ArrayList<>();
        for (int i = 1; i < 255; i++) {
            final String host = prefix + i;
            fs.add(pool.submit(() -> {
                String r = get(host, "/cpursx.ps3", 800, 200000);
                return (r != null && r.toLowerCase().contains("cpu")) ? host : null;
            }));
        }
        String found = null;
        for (Future<String> f : fs) {
            try {
                String r = f.get();
                if (r != null) { found = r; break; }
            } catch (Exception ignored) { }
        }
        pool.shutdownNow();
        return found;
    }
}
