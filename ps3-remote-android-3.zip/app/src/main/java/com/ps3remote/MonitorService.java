package com.ps3remote;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MonitorService extends Service {
    volatile boolean run;
    Thread th;
    NotificationManager nm;
    int notifId = 2000;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("mon", "Monitoring", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel("alert", "PS3 alerts", NotificationManager.IMPORTANCE_HIGH));
        Notification n = ongoing("Monitoring PS3...");
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        if (th == null || !th.isAlive()) {
            run = true;
            th = new Thread(this::loop);
            th.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        run = false;
        if (th != null) th.interrupt();
        super.onDestroy();
    }

    PendingIntent open() {
        return PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
    }

    Notification ongoing(String text) {
        return new Notification.Builder(this, "mon").setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("PS3 Remote").setContentText(text).setOngoing(true).setContentIntent(open()).build();
    }

    void alert(String title, String text, int icon) {
        nm.notify(notifId++, new Notification.Builder(this, "alert").setSmallIcon(icon)
            .setContentTitle(title).setContentText(text).setAutoCancel(true).setContentIntent(open()).build());
    }

    static String find(String s, String re, int g) {
        if (s == null) return null;
        Matcher m = Pattern.compile(re, Pattern.DOTALL).matcher(s);
        return m.find() ? m.group(g) : null;
    }

    static Set<String> findAll(String s, String re) {
        Set<String> out = new LinkedHashSet<>();
        if (s == null) return out;
        Matcher m = Pattern.compile(re).matcher(s);
        while (m.find() && out.size() < 300) out.add(m.group(1));
        return out;
    }

    static int temp(String body, String label) {
        String v = find(body, label + "[^0-9]{0,15}(\\d{2,3})", 1);
        return v == null ? -1 : Integer.parseInt(v);
    }

    void loop() {
        SharedPreferences p = Net.prefs(this);
        long lastAlert = 0;
        while (run) {
            String ip = Net.ip(this);
            int thr = p.getInt("thr", 75);
            if (!ip.isEmpty()) {
                String body = Net.get(ip, "/cpursx.ps3", 3000, 300000);
                long now = System.currentTimeMillis();
                if (body != null) {
                    int cpu = temp(body, "CPU"), rsx = temp(body, "RSX");
                    p.edit().putString("temps", cpu + "," + rsx).putLong("tempsAt", now).apply();
                    nm.notify(1, ongoing("CPU " + cpu + "\u00b0C  \u00b7  RSX " + rsx + "\u00b0C"));
                    int hot = Math.max(cpu, rsx);
                    if (hot >= thr && now - lastAlert > 300000) {
                        lastAlert = now;
                        alert("PS3 is hot", "CPU " + cpu + "\u00b0C / RSX " + rsx + "\u00b0C (limit " + thr + "\u00b0C)",
                            android.R.drawable.stat_sys_warning);
                    }
                } else {
                    p.edit().putString("temps", "-1,-1").apply();
                    nm.notify(1, ongoing("PS3 not reachable"));
                }
            }
            try { Thread.sleep(20000); } catch (InterruptedException e) { break; }
        }
    }
}
