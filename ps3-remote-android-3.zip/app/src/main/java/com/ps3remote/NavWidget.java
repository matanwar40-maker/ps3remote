package com.ps3remote;

public class NavWidget extends PadWidget {
    static final int[] IDS = {R.id.n_back,R.id.n_ps,R.id.n_opt,R.id.n_up,R.id.n_left,R.id.n_ok,R.id.n_right,R.id.n_down};
    static final String[] CMDS = {"circle","psbtn","triangle","up","left","cross","right","down"};
    @Override int layout() { return R.layout.widget_nav; }
    @Override int[] ids() { return IDS; }
    @Override String[] cmds() { return CMDS; }
}
