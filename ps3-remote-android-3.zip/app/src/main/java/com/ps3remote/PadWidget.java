package com.ps3remote;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.RemoteViews;
import android.widget.Toast;

public abstract class PadWidget extends AppWidgetProvider {
    abstract int layout();
    abstract int[] ids();
    abstract String[] cmds();

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] widgetIds) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), layout());
        int[] ids = ids();
        String[] cmds = cmds();
        for (int i = 0; i < ids.length; i++) {
            Intent in = new Intent(ctx, getClass()).setAction("PAD").putExtra("cmd", cmds[i]);
            rv.setOnClickPendingIntent(ids[i], PendingIntent.getBroadcast(ctx, i, in,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        }
        mgr.updateAppWidget(widgetIds, rv);
    }

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        if (!"PAD".equals(intent.getAction())) return;
        final String cmd = intent.getStringExtra("cmd");
        buzz(ctx);
        final BroadcastReceiver.PendingResult pr = goAsync();
        new Thread(() -> {
            String ip = Net.ip(ctx);
            if (ip.isEmpty()) {
                toast(ctx, "Open the app and save the IP first");
            } else if (Net.get(ip, "/pad.ps3?" + cmd, 2000, 20000) == null) {
                toast(ctx, "PS3 unreachable");
            }
            pr.finish();
        }).start();
    }

    @SuppressWarnings("deprecation")
    static void buzz(Context c) {
        try {
            Vibrator v = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(14, VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(14);
        } catch (Exception ignored) { }
    }

    static void toast(final Context c, final String m) {
        new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(c, m, Toast.LENGTH_SHORT).show());
    }
}
