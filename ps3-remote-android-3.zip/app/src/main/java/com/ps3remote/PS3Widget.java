package com.ps3remote;

public class PS3Widget extends PadWidget {
    static final int[] IDS = {R.id.f_l2,R.id.f_l1,R.id.f_r1,R.id.f_r2,R.id.f_up,R.id.f_left,R.id.f_ok,R.id.f_right,R.id.f_down,R.id.f_tri,R.id.f_sq,R.id.f_ci,R.id.f_cr,R.id.f_select,R.id.f_ps,R.id.f_start};
    static final String[] CMDS = {"l2","l1","r1","r2","up","left","cross","right","down","triangle","square","circle","cross","select","psbtn","start"};
    @Override int layout() { return R.layout.widget_full; }
    @Override int[] ids() { return IDS; }
    @Override String[] cmds() { return CMDS; }
}
