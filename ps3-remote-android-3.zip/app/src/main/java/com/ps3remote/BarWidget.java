package com.ps3remote;

public class BarWidget extends PadWidget {
    static final int[] IDS = {R.id.q_ps,R.id.q_back,R.id.q_ok,R.id.q_opt,R.id.q_start};
    static final String[] CMDS = {"psbtn","circle","cross","triangle","start"};
    @Override int layout() { return R.layout.widget_bar; }
    @Override int[] ids() { return IDS; }
    @Override String[] cmds() { return CMDS; }
}
