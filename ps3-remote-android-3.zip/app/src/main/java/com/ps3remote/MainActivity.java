package com.ps3remote;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    WebView wv;
    final ExecutorService ex = Executors.newFixedThreadPool(6);
    final ExecutorService padEx = Executors.newSingleThreadExecutor();
    final AtomicInteger pending = new AtomicInteger();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        wv = new WebView(this);
        wv.setBackgroundColor(Color.BLACK);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        wv.addJavascriptInterface(new Bridge(), "Native");
        wv.loadUrl("file:///android_asset/index.html");
    }

    void js(final String type, final String payload) {
        runOnUiThread(() -> wv.evaluateJavascript(
            "window.onNative(" + JSONObject.quote(type) + "," + JSONObject.quote(payload) + ")", null));
    }

    class Bridge {
        @JavascriptInterface
        public String getIp() { return Net.ip(MainActivity.this); }

        @JavascriptInterface
        public void setIp(String ip) { Net.prefs(MainActivity.this).edit().putString("ip", ip.trim()).apply(); }

        @JavascriptInterface
        public void pad(final String cmd) {
            if (!cmd.matches("[A-Za-z0-9_]+")) return;
            if (pending.get() > 3 && !cmd.equals("release")) return;
            pending.incrementAndGet();
            padEx.execute(() -> {
                String r = Net.get(Net.ip(MainActivity.this), "/pad.ps3?" + cmd, 2500, 20000);
                pending.decrementAndGet();
                js("send", r != null ? "ok" : "fail");
            });
        }

        @JavascriptInterface
        public void startMonitor(int thr) {
            Net.prefs(MainActivity.this).edit().putInt("thr", thr).putBoolean("mon", true).apply();
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                startForegroundService(new Intent(MainActivity.this, MonitorService.class));
            });
        }

        @JavascriptInterface
        public void setAlerts(int thr) {
            Net.prefs(MainActivity.this).edit().putInt("thr", thr).apply();
        }

        @JavascriptInterface
        public void stopMonitor() {
            Net.prefs(MainActivity.this).edit().putBoolean("mon", false).apply();
            runOnUiThread(() -> stopService(new Intent(MainActivity.this, MonitorService.class)));
        }

        @JavascriptInterface
        public String monitorState() {
            android.content.SharedPreferences p = Net.prefs(MainActivity.this);
            try {
                JSONObject o = new JSONObject();
                o.put("on", p.getBoolean("mon", false));
                o.put("thr", p.getInt("thr", 75));
                o.put("temps", p.getString("temps", "-1,-1"));
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface
        public void scan() {
            ex.execute(() -> {
                String f = Net.scan(MainActivity.this);
                js("scan", f == null ? "" : f);
            });
        }
    }
}
